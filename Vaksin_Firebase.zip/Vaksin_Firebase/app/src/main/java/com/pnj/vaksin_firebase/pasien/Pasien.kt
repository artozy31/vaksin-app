package com.pnj.vaksin_firebase.pasien

data class Pasien(
    var nik: String? = null,
    var nama: String?= null,
    var tgl_lahir: String?= null,
    var jenis_kelamin: String?= null,
    var penyakit_bawaan: String?= null,
)